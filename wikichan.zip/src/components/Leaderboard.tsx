import { useState } from 'react';
import { CURRENCY } from '../lib/config';
import { formatNumber, useLeaderboard, type Player } from '../lib/leaderboard';
import { cn } from '../utils/cn';

const PODIUM: Record<number, { medal: string; row: string; badge: string }> = {
  1: {
    medal: '🥇',
    row: 'bg-gradient-to-r from-amber-100 via-yellow-50 to-white border-amber-200',
    badge: 'bg-amber-400 text-white',
  },
  2: {
    medal: '🥈',
    row: 'bg-gradient-to-r from-slate-100 via-slate-50 to-white border-slate-200',
    badge: 'bg-slate-400 text-white',
  },
  3: {
    medal: '🥉',
    row: 'bg-gradient-to-r from-orange-100 via-orange-50 to-white border-orange-200',
    badge: 'bg-orange-400 text-white',
  },
};

function Avatar({ player }: { player: Player }) {
  const [failed, setFailed] = useState(false);
  const hue = (player.username.charCodeAt(0) * 47) % 360;

  if (!player.avatar || failed) {
    return (
      <div
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-base font-bold text-white"
        style={{ background: `linear-gradient(135deg, hsl(${hue} 80% 70%), hsl(${(hue + 40) % 360} 80% 62%))` }}
      >
        {player.username.charAt(0).toUpperCase()}
      </div>
    );
  }

  return (
    <img
      src={player.avatar}
      alt=""
      loading="lazy"
      onError={() => setFailed(true)}
      className="h-11 w-11 shrink-0 rounded-full object-cover ring-2 ring-white"
    />
  );
}

function Skeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className="flex animate-pulse items-center gap-4 rounded-2xl border border-pink-100 bg-white/70 p-3">
          <div className="h-8 w-8 rounded-full bg-pink-100" />
          <div className="h-11 w-11 rounded-full bg-pink-100" />
          <div className="h-4 flex-1 rounded bg-pink-100" />
          <div className="h-4 w-20 rounded bg-pink-100" />
        </div>
      ))}
    </div>
  );
}

export default function Leaderboard() {
  const { data, status, reload } = useLeaderboard();
  const users = data?.users ?? [];

  return (
    <section id="top" className="mx-auto max-w-3xl px-5 py-20">
      <div className="mb-10 text-center">
        <p className="text-sm font-semibold tracking-widest text-pink-500 uppercase">Bảng xếp hạng</p>
        <h2 className="mt-2 text-3xl font-extrabold text-purple-950 sm:text-4xl">Top 10 người giàu nhất 👑</h2>
        <p className="mt-3 text-purple-900/60">Tính chung tất cả server có Wiki Chan.</p>
      </div>

      <div className="rounded-3xl border border-white bg-white/60 p-4 shadow-xl shadow-pink-200/50 backdrop-blur sm:p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 px-1 text-xs">
          <span
            className={cn(
              'inline-flex items-center gap-2 rounded-full px-3 py-1 font-semibold',
              status === 'live' && 'bg-emerald-100 text-emerald-700',
              status === 'sample' && 'bg-amber-100 text-amber-700',
              status === 'loading' && 'bg-purple-100 text-purple-700'
            )}
          >
            <span
              className={cn(
                'h-2 w-2 rounded-full',
                status === 'live' && 'bg-emerald-500',
                status === 'sample' && 'bg-amber-500',
                status === 'loading' && 'animate-pulse bg-purple-500'
              )}
            />
            {status === 'live' && 'Dữ liệu trực tiếp'}
            {status === 'sample' && 'Dữ liệu mẫu (chưa kết nối bot)'}
            {status === 'loading' && 'Đang tải...'}
          </span>
          <button
            onClick={reload}
            className="rounded-full px-3 py-1 font-semibold text-purple-600 transition hover:bg-purple-100"
          >
            ↻ Làm mới
          </button>
        </div>

        {status === 'loading' && users.length === 0 ? (
          <Skeleton />
        ) : users.length === 0 ? (
          <div className="py-14 text-center">
            <div className="text-5xl">🌸</div>
            <p className="mt-3 font-semibold text-purple-950">Chưa có ai trên bảng xếp hạng</p>
            <p className="mt-1 text-sm text-purple-900/60">
              Dùng lệnh <code className="rounded bg-pink-100 px-1.5 py-0.5 text-pink-600">/daily</code> trên Discord để
              là người đầu tiên!
            </p>
          </div>
        ) : (
          <ol className="space-y-2.5">
            {users.map((p) => {
              const podium = PODIUM[p.rank];
              return (
                <li
                  key={p.rank}
                  className={cn(
                    'flex items-center gap-3 rounded-2xl border p-3 transition hover:-translate-y-0.5 hover:shadow-md sm:gap-4',
                    podium ? podium.row : 'border-pink-100 bg-white/80'
                  )}
                >
                  <div
                    className={cn(
                      'flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold',
                      podium ? podium.badge : 'bg-purple-100 text-purple-600'
                    )}
                  >
                    {p.rank}
                  </div>
                  <Avatar player={p} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-bold text-purple-950">
                      {podium?.medal} {p.username}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-extrabold text-pink-600">
                      {CURRENCY.emoji} {formatNumber(p.balance)}
                    </p>
                    <p className="text-[11px] font-medium text-purple-900/40">{CURRENCY.short}</p>
                  </div>
                </li>
              );
            })}
          </ol>
        )}

        {data?.totalPlayers !== undefined && users.length > 0 && (
          <p className="mt-5 text-center text-xs text-purple-900/50">
            Tổng cộng <b>{formatNumber(data.totalPlayers)}</b> người chơi đã tham gia
          </p>
        )}
      </div>
    </section>
  );
}
