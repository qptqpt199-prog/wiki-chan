// CLIENT_ID là thông tin công khai nên có thể đặt trong code web.
export const CLIENT_ID = '1566673824563339266';

// Quyền: Send Messages (2048) + Embed Links (16384)
export const INVITE_URL = `https://discord.com/oauth2/authorize?client_id=${CLIENT_ID}&permissions=18432&scope=bot%20applications.commands`;

export const CURRENCY = { name: 'Wiki Chan Coin', short: 'WCC', emoji: '🪙' };

export const COMMANDS = [
  {
    name: '/daily',
    emoji: '🎁',
    desc: 'Nhận quà mỗi 24 giờ. Điểm danh liên tiếp để được cộng thêm thưởng chuỗi ngày.',
    detail: '500 WCC + 50 WCC mỗi ngày liên tiếp (tối đa 7 ngày)',
  },
  {
    name: '/top',
    emoji: '👑',
    desc: 'Xem bảng xếp hạng 10 người giàu nhất, tính chung tất cả server.',
    detail: 'Hiện luôn hạng của bạn nếu nằm ngoài top',
  },
  {
    name: '/balance',
    emoji: '👛',
    desc: 'Xem số dư và thứ hạng của bạn hoặc của bạn bè.',
    detail: 'Có thể chọn người khác để xem ví',
  },
];
