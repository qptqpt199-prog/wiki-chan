import { useCallback, useEffect, useState } from 'react';

export interface Player {
  rank: number;
  username: string;
  avatar?: string;
  balance: number;
}

export interface LeaderboardData {
  users: Player[];
  totalPlayers?: number;
  updatedAt?: string;
}

// Dữ liệu mẫu, chỉ dùng khi chưa kết nối được API thật (ví dụ khi xem trước)
const SAMPLE: LeaderboardData = {
  totalPlayers: 128,
  users: [
    { rank: 1, username: 'Sakura', balance: 48250 },
    { rank: 2, username: 'Minh Anh', balance: 41900 },
    { rank: 3, username: 'Hoshi', balance: 37400 },
    { rank: 4, username: 'Bảo Ngọc', balance: 29800 },
    { rank: 5, username: 'Kuro', balance: 24650 },
    { rank: 6, username: 'Thỏ Con', balance: 19300 },
    { rank: 7, username: 'Nguyệt', balance: 15200 },
    { rank: 8, username: 'Mochi', balance: 11850 },
    { rank: 9, username: 'Hải Đăng', balance: 8400 },
    { rank: 10, username: 'Yuki', balance: 5150 },
  ],
};

export type Status = 'loading' | 'live' | 'sample';

export function useLeaderboard() {
  const [data, setData] = useState<LeaderboardData | null>(null);
  const [status, setStatus] = useState<Status>('loading');

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/leaderboard', { headers: { Accept: 'application/json' } });
      const type = res.headers.get('content-type') || '';
      if (!res.ok || !type.includes('application/json')) throw new Error('API chưa sẵn sàng');
      const json = (await res.json()) as LeaderboardData;
      setData(json);
      setStatus('live');
    } catch {
      setData((prev) => prev ?? SAMPLE);
      setStatus((prev) => (prev === 'live' ? 'live' : 'sample'));
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 60_000); // làm mới mỗi phút
    return () => clearInterval(id);
  }, [load]);

  return { data, status, reload: load };
}

export const formatNumber = (n: number) => new Intl.NumberFormat('vi-VN').format(Math.floor(n));
