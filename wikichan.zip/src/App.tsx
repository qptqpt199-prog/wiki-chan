import Leaderboard from './components/Leaderboard';
import { COMMANDS, CURRENCY, INVITE_URL } from './lib/config';

function Mascot() {
  return (
    <div className="relative mx-auto h-56 w-56 sm:h-64 sm:w-64">
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-pink-300 via-fuchsia-300 to-purple-300 opacity-60 blur-2xl" />
      <div className="relative flex h-full w-full items-center justify-center rounded-full border-8 border-white bg-gradient-to-br from-pink-200 to-purple-200 shadow-2xl shadow-pink-300/60">
        <svg viewBox="0 0 120 120" className="h-40 w-40 sm:h-48 sm:w-48">
          {/* tai */}
          <path d="M28 40 L22 8 L50 28 Z" fill="#f9a8d4" />
          <path d="M92 40 L98 8 L70 28 Z" fill="#f9a8d4" />
          <path d="M29 33 L27 17 L41 27 Z" fill="#fff" opacity=".7" />
          <path d="M91 33 L93 17 L79 27 Z" fill="#fff" opacity=".7" />
          {/* mặt */}
          <circle cx="60" cy="68" r="42" fill="#fff" />
          {/* mắt */}
          <ellipse cx="44" cy="66" rx="5.5" ry="7" fill="#4c1d95" />
          <ellipse cx="76" cy="66" rx="5.5" ry="7" fill="#4c1d95" />
          <circle cx="46" cy="63" r="2" fill="#fff" />
          <circle cx="78" cy="63" r="2" fill="#fff" />
          {/* má hồng */}
          <ellipse cx="33" cy="80" rx="8" ry="5" fill="#f9a8d4" opacity=".7" />
          <ellipse cx="87" cy="80" rx="8" ry="5" fill="#f9a8d4" opacity=".7" />
          {/* miệng */}
          <path d="M53 80 Q60 88 67 80" stroke="#be185d" strokeWidth="3" fill="none" strokeLinecap="round" />
          {/* nơ */}
          <path d="M60 30 L48 22 L48 38 Z M60 30 L72 22 L72 38 Z" fill="#c084fc" />
          <circle cx="60" cy="30" r="4" fill="#a855f7" />
        </svg>
        <span className="absolute -top-1 right-2 animate-bounce text-4xl">🪙</span>
        <span className="absolute bottom-3 left-0 animate-pulse text-3xl">✨</span>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-b from-pink-50 via-fuchsia-50 to-purple-100 font-sans text-purple-950">
      {/* nền trang trí */}
      <div className="pointer-events-none absolute -top-32 -left-32 h-96 w-96 rounded-full bg-pink-300/40 blur-3xl" />
      <div className="pointer-events-none absolute top-[40rem] -right-40 h-[28rem] w-[28rem] rounded-full bg-purple-300/40 blur-3xl" />

      {/* thanh điều hướng */}
      <header className="relative z-10 mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <a href="#" className="flex items-center gap-2 text-lg font-extrabold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-pink-400 to-purple-500 text-lg shadow-md">
            🌸
          </span>
          Wiki Chan
        </a>
        <nav className="flex items-center gap-1 text-sm font-semibold text-purple-900/70">
          <a href="#lenh" className="rounded-full px-3 py-2 transition hover:bg-white/70">
            Lệnh
          </a>
          <a href="#top" className="rounded-full px-3 py-2 transition hover:bg-white/70">
            Xếp hạng
          </a>
        </nav>
      </header>

      {/* hero */}
      <main className="relative z-10">
        <section className="mx-auto grid max-w-5xl items-center gap-10 px-5 pt-8 pb-16 md:grid-cols-2 md:pt-14">
          <div className="text-center md:text-left">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-1.5 text-xs font-bold text-pink-600 shadow-sm">
              <span className="h-2 w-2 animate-pulse rounded-full bg-pink-500" />
              Bot mini game cho Discord
            </span>
            <h1 className="mt-5 text-5xl leading-tight font-black tracking-tight sm:text-6xl">
              Xin chào, mình là{' '}
              <span className="bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-600 bg-clip-text text-transparent">
                Wiki Chan
              </span>
              !
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-purple-900/70">
              Điểm danh mỗi ngày để nhận <b>{CURRENCY.name}</b>, so tài với bạn bè và leo lên top người giàu nhất trên
              mọi server. Nhiều mini game thú vị đang trên đường đến!
            </p>

            <div className="mt-8 flex flex-wrap justify-center gap-3 md:justify-start">
              <a
                href={INVITE_URL}
                target="_blank"
                rel="noreferrer"
                className="rounded-full bg-gradient-to-r from-pink-500 to-purple-600 px-7 py-3.5 font-bold text-white shadow-lg shadow-pink-300/60 transition hover:-translate-y-0.5 hover:shadow-xl"
              >
                Mời Wiki Chan vào server 💌
              </a>
              <a
                href="#top"
                className="rounded-full border-2 border-white bg-white/70 px-7 py-3.5 font-bold text-purple-700 transition hover:bg-white"
              >
                Xem bảng xếp hạng
              </a>
            </div>

            <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-purple-900/60 md:justify-start">
              <span>
                {CURRENCY.emoji} Tiền tệ: <b className="text-purple-900">{CURRENCY.short}</b>
              </span>
              <span>
                🌐 Dùng chung <b className="text-purple-900">liên server</b>
              </span>
              <span>
                💸 <b className="text-purple-900">Miễn phí</b>
              </span>
            </div>
          </div>

          <Mascot />
        </section>

        {/* danh sách lệnh */}
        <section id="lenh" className="mx-auto max-w-5xl px-5 py-16">
          <div className="mb-10 text-center">
            <p className="text-sm font-semibold tracking-widest text-pink-500 uppercase">Bắt đầu chơi</p>
            <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">Các lệnh cơ bản ✨</h2>
            <p className="mt-3 text-purple-900/60">Gõ dấu / trong Discord rồi chọn lệnh của Wiki Chan.</p>
          </div>

          <div className="grid gap-5 md:grid-cols-3">
            {COMMANDS.map((c) => (
              <div
                key={c.name}
                className="group rounded-3xl border border-white bg-white/70 p-6 shadow-lg shadow-pink-200/40 backdrop-blur transition hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-100 to-purple-100 text-3xl transition group-hover:scale-110">
                  {c.emoji}
                </div>
                <code className="mt-4 inline-block rounded-lg bg-purple-950 px-3 py-1 text-sm font-bold text-pink-200">
                  {c.name}
                </code>
                <p className="mt-3 leading-relaxed text-purple-900/70">{c.desc}</p>
                <p className="mt-3 border-t border-pink-100 pt-3 text-xs font-medium text-pink-600">{c.detail}</p>
              </div>
            ))}
          </div>
        </section>

        <Leaderboard />
      </main>

      <footer className="relative z-10 border-t border-white/70 py-8 text-center text-sm text-purple-900/50">
        Made with 💜 • Wiki Chan Bot • Dữ liệu cập nhật tự động
      </footer>
    </div>
  );
}
